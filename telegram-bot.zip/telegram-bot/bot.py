#!/usr/bin/env python3
import os
import logging
import httpx
from telegram import Update
from telegram.request import HTTPXRequest
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters, ContextTypes,
)

# 加载 .env 文件
_env_file = os.path.join(os.path.dirname(__file__), "..", ".env")
if os.path.exists(_env_file):
    with open(_env_file) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())

import config
from handlers import commands

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)


class DirectHTTPXRequest(HTTPXRequest):
    """Keep Telegram traffic independent from the macOS system proxy."""

    def _build_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(trust_env=False, **self._client_kwargs)


async def post_init(app: Application):
    """Set up bot command menu and menu button."""
    from telegram import BotCommand
    commands.configure_bot(app.bot)
    await app.bot.set_my_commands([
        BotCommand("start", "开始使用 / 重新打开菜单"),
        BotCommand("recharge", "充值余额"),
        BotCommand("me", "个人中心 / 查看余额"),
        BotCommand("pdd", "分享赚钱 / 推荐有礼"),
        BotCommand("sc", "生成图片"),
        BotCommand("gt", "改图"),
    ])


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_start(update, context)


async def recharge_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_recharge(update, context)


async def me_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_me(update, context)


async def pdd_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_pdd(update, context)


async def sc_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_image_gen_sc_direct(update, context)


async def gt_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_image_edit_gt_direct(update, context)


async def zs_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await commands.cmd_zs(update, context)


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data if update.callback_query else ""
    if data.startswith("confirm_"):
        await commands.handle_confirm_callback(update, context)
    elif data.startswith("gen_"):
        await commands.handle_confirm_callback(update, context)
    elif data.startswith("action_"):
        await commands.handle_confirm_callback(update, context)
    elif data.startswith("do_action_"):
        await commands.handle_confirm_callback(update, context)
    elif data.startswith("continue_edit"):
        await commands.handle_confirm_callback(update, context)
    elif data.startswith("lang_"):
        await commands.handle_lang_callback(update, context)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("Unhandled Telegram update error", exc_info=context.error)


def main():
    if not config.BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set! Please set it in .env file.")
        return

    request = DirectHTTPXRequest(connection_pool_size=10, read_timeout=60, connect_timeout=10)
    get_updates_request = DirectHTTPXRequest(connection_pool_size=2, read_timeout=60, connect_timeout=10)
    app = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .request(request)
        .get_updates_request(get_updates_request)
        .post_init(post_init)
        .build()
    )

    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("recharge", recharge_cmd))
    app.add_handler(CommandHandler("me", me_cmd))
    app.add_handler(CommandHandler("pdd", pdd_cmd))
    app.add_handler(CommandHandler("sc", sc_cmd))
    app.add_handler(CommandHandler("gt", gt_cmd))
    app.add_handler(CommandHandler("zs", zs_cmd))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(
        filters.PHOTO & ~filters.COMMAND,
        commands.handle_photo_message
    ))
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        commands.handle_message
    ))
    app.add_error_handler(error_handler)

    logger.info("Bot starting...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
